
function navigateTo(page) {
    window.location.href = page;
}

function navigateBack() {
    window.history.back();
}
